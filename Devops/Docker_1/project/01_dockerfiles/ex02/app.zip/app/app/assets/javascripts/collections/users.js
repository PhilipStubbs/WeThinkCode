Kanban.Collections.Users = Backbone.Collection.extend({
  model: Kanban.Models.User,
  url: '/api/users',

});
