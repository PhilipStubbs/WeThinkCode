Kanban.Models.User = Backbone.RelationalModel.extend({
  urlRoot: '/api/users'
});
