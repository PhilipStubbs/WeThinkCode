Kanban.Views.CardCommentsIndex = Backbone.View.extend({
  template: JST['card_comments/index']
});
