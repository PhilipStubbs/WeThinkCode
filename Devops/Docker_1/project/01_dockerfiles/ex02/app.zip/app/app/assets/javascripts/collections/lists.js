Kanban.Collections.Lists = Backbone.Collection.extend({
  model: Kanban.Models.List
});
