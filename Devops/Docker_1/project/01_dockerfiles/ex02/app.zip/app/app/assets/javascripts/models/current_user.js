Kanban.Models.CurrentUser = Kanban.Models.User.extend({
  urlRoot: '/api/users/current'
});
