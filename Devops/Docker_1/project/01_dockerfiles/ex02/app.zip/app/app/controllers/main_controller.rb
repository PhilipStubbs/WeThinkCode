class MainController < ApplicationController

  def index
    render :index
  end
end
