# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Kanban::Application.config.secret_token = '892f30d7304fd536f9a715d90c5ca5d772d9196de0cafe6a2bda86f881065410e731429d1a7ed8499f6e0d189e76d76eab48ae9d1875ff100c6fc79e9b971c75'
